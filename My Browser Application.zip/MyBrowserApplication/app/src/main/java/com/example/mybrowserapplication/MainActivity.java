package com.example.mybrowserapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebBackForwardList;
import android.webkit.WebHistoryItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{

    String currenturl = "";
    String homepage = "https://www.google.com";
    String curretpage = "";
    String oldpage = "";
    ArrayList<Favorite> favelist = new ArrayList<>();
    ArrayList<Favorite> historyitems = new ArrayList<>();
    List<Favorite> fullList = new ArrayList<>();
    ArrayList<Favorite> historylastsession = new ArrayList<>();
    ArrayList<Favorite> historycombind = new ArrayList<>();
    private FaveListAdapter faveListAdapter;
    static final int TEST = 0;
    static final int EMPTY = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //loadbackforward();
        //WebBackForwardList = savehist;
        loadfave();
        loadhome();
        loadcurrent();
        loadhistory();
        browserpage();
    }

    public void onPause() {
        savefave();
        savehome();
        savecurrent();

        //savebackforward();
        super.onPause();
    }

    public void onResume() {
        loadfave();
       // loadbackforward();
        loadhome();
        loadcurrent();
        loadhistory();
        super.onResume();
    }

    public void onStop() {
        savehistory();
        curretpage = "";
        super.onStop();
    }

    private void savehome(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(homepage);
        editor.putString("homepage", json);
        editor.apply();
    }

    private void loadhome(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("homepage", null);
        Type type = new TypeToken<String>() {}.getType();
        homepage = gson.fromJson(json, type);

        if(homepage==null){
            homepage = "https://www.google.com";
        }
    }

    private void savecurrent(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(curretpage);
        editor.putString("currentpage", json);
        editor.apply();
    }

    private void loadcurrent(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("currentpage", null);
        Type type = new TypeToken<String>() {}.getType();
        curretpage = gson.fromJson(json, type);
    }

    private void savefave(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(favelist);
        editor.putString("favelist", json);
        editor.apply();
    }

    private void loadfave(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("favelist", null);
        Type type = new TypeToken<ArrayList<Favorite>>() {}.getType();
        favelist = gson.fromJson(json, type);

        if(favelist==null){
            favelist = new ArrayList<>();
        }
    }

    private void savehistory(){
        //ArrayList<Favorite> historylastsession = new ArrayList<>();
        /*
        for (int i = 0; i <historyitems.size(); i++){
            Favorite item = historyitems.get(i);
            String url = item.getUrl();
            String name = item.getUrl();
            Favorite historyitem = new Favorite(url, name);
            historylastsession.add(historyitem);
        }
         */

        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(historycombind);
        editor.putString("history", json);
        editor.apply();
    }

    private void loadhistory(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("history", null);
        Type type = new TypeToken<ArrayList<Favorite>>() {}.getType();
        historylastsession = gson.fromJson(json, type);

    }
/*
    private void savebackforward(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(savehist);
        editor.putString("savehist", json);
        editor.apply();
    }

    private void loadbackforward(){
        SharedPreferences sharedPreferences = getSharedPreferences("shared", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("WebBackForwardList", null);
        Type type = new TypeToken<ArrayList<Favorite>>() {}.getType();
        savehist = gson.fromJson(json, type);
    }
*/


    public void browserpage(){

        fullList.clear();
        setContentView(R.layout.activity_main);
        WebView myWebView = (WebView) findViewById(R.id.webview);
        //setContentView(myWebView);
        Button btn = (Button) findViewById(R.id.gobtn);
        ImageView btnBack = (ImageView) findViewById(R.id.backbtn);
        ImageView btnForward = (ImageView) findViewById(R.id.forwardbtn);
        ImageView btnHome = (ImageView) findViewById(R.id.homebtn);
        ImageView btnrefresh = (ImageView) findViewById(R.id.btnrefresh);
        ImageView btnfav = (ImageView) findViewById(R.id.btnfav);
        ImageView btnmenu = (ImageView) findViewById(R.id.btnmenu);
        ImageView btntab = (ImageView) findViewById(R.id.tabbtn);

        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        if (curretpage == null || curretpage.equals("")){
            curretpage = homepage;
        }
        myWebView.loadUrl(curretpage);

        WebViewClient myWebViewClient = new WebViewClient();
        myWebView.setWebViewClient(myWebViewClient);

        WebBackForwardList webviewHistory = myWebView.copyBackForwardList();
        curretpage = myWebView.getUrl();

        myWebView.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView view, String url) {
                //savehist.clear();
                curretpage = myWebView.getUrl();
                //WebBackForwardList savehistory = myWebView.copyBackForwardList();

            }
        });

        btn.setOnClickListener((View v) -> {
            TextInputEditText in = (TextInputEditText) findViewById(R.id.urlinput);
            if (in != null) {
                myWebView.loadUrl(in.getText().toString());
            }
        });

        btnBack.setOnClickListener((View v) -> {
            if (myWebView.canGoBack()) {
                myWebView.goBack();
            }
        });

        btnForward.setOnClickListener((View v) -> {
            if (myWebView.canGoForward()) {
                myWebView.goForward();
            }
        });

        btnHome.setOnClickListener((View v) -> {
            myWebView.loadUrl(homepage);
        });

        btnrefresh.setOnClickListener((View v) -> {
            myWebView.reload();
        });

        btnfav.setOnClickListener((View v) -> {
            Boolean add = true;
            Favorite favorite = new Favorite(myWebView.getUrl(), myWebView.getTitle());
            for (int i = 0; i < favelist.size(); i++){
                if (favelist.get(i).getUrl().equals(favorite.getUrl())){
                    add = false;
                }
            }
            if(add == true) {
                favelist.add(favorite);
                Toast.makeText(this, "New favorite added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Already a favorite", Toast.LENGTH_SHORT).show();
            }
        });

        btnmenu.setOnClickListener((View v) -> {

            historycombind.clear();
            currenturl = myWebView.getUrl();

            WebBackForwardList currentList = myWebView.copyBackForwardList();

            int currentSize = currentList.getSize();
            for(int i = 0; i < currentSize; i++)
            {
                WebHistoryItem item = currentList.getItemAtIndex(i);
                String url = item.getUrl();
                String name = item.getUrl();
                Favorite historyitem = new Favorite(url, name);
                historyitems.add(historyitem);
            }
            //historycombind.addAll(historylastsession);
            if (historylastsession != null) {
                for (int i = 0; i < historylastsession.size(); i++) {
                    historycombind.add(historylastsession.get(i));
                }
            }

            for (int i = 0; i < historyitems.size(); i++){
                historycombind.add(historyitems.get(i));
            }
            //historycombind.addAll(historyitems);
            showPopup(v);

        });
    }

    public void showPopup(View v){
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    public void showfavePopup(View v){
        PopupMenu popupfave = new PopupMenu(this, v);
        popupfave.setOnMenuItemClickListener(this);
        popupfave.inflate(R.menu.fmenu);
        popupfave.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                homepage = currenturl;
                Toast.makeText(this, "New home set", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item2:
                Toast.makeText(this, "Favorites", Toast.LENGTH_SHORT).show();
                setupScreen(TEST);
                return true;
            case R.id.item3:
                //Toast.makeText(this, "Item 3 clicked", Toast.LENGTH_SHORT).show();
                setupScreenhist(TEST);

                return true;
            case R.id.item4:
                Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show();
                historycombind.clear();
                historyitems.clear();
                historylastsession.clear();
                return true;
            case R.id.remove:
                Toast.makeText(this, "Item 3 clicked", Toast.LENGTH_SHORT).show();
                for(int i = 0; i < favelist.size(); i++){
                    if (favelist.get(i).getUrl().equals(curretpage)){
                        favelist.remove(i);
                    }setupScreen(TEST);
                }
                curretpage = oldpage;
                return true;
            case R.id.gogo:
                browserpage();
                return true;

            default:
                return false;
        }
    }

    private void setupScreen(int state){
        setContentView(R.layout.favorites);
        ListView list = (ListView)findViewById(R.id.listView);
        Button btnb = (Button) findViewById(R.id.buttonbacktomain);

        switch (state){
            case TEST:
                setTitle(R.string.test_title);

                FaveListAdapter listaddapter = new FaveListAdapter(this, favelist);

                List<Favorite> fullList = new ArrayList<>();
                for(int i = 0; i<favelist.size(); i++){
                    fullList.add(favelist.get(i));
                }
                faveListAdapter = new FaveListAdapter(this, fullList);

                break;

            case EMPTY:
                setTitle(R.string.empty_title);

                List<Favorite> emptyList = new ArrayList<Favorite>();
                emptyList.add(new Favorite(getString(R.string.space), getString(R.string.nocry)));

                faveListAdapter = new FaveListAdapter(this, emptyList);

                break;
        }

        list.setAdapter(faveListAdapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                oldpage = curretpage;
                curretpage = favelist.get(position).getUrl();
                showfavePopup(view);
                //browserpage();
            }
        });

        btnb.setOnClickListener((View v) -> {
            historyitems.remove(historyitems.size()-1);
            browserpage();
        });
    }

    private void setupScreenhist(int state){
        setContentView(R.layout.favorites);
        ListView list = (ListView)findViewById(R.id.listView);
        Button btnb = (Button) findViewById(R.id.buttonbacktomain);

        switch (state){
            case TEST:
                setTitle(R.string.test_title);

                FaveListAdapter listaddapter = new FaveListAdapter(this, historycombind);

                //List<Favorite> fullList = new ArrayList<>();
                for(int i = 0; i<historycombind.size(); i++){
                    fullList.add(historycombind.get((historycombind.size()-1)-i));
                }
                faveListAdapter = new FaveListAdapter(this, fullList);

                break;

            case EMPTY:
                setTitle(R.string.empty_title);
                List<Favorite> emptyList = new ArrayList<Favorite>();
                emptyList.add(new Favorite(getString(R.string.space), getString(R.string.nocry)));
                faveListAdapter = new FaveListAdapter(this, emptyList);
                break;
        }

        list.setAdapter(faveListAdapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                curretpage = fullList.get(position).getUrl();
                browserpage();
            }
        });

        btnb.setOnClickListener((View v) -> {
            historyitems.remove(historyitems.size()-1);
            browserpage();
        });
    }
}