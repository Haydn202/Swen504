package com.example.mybrowserapplication;

public class Favorite {
    private String url;
    private String name;

    public Favorite(String url, String name){
        this.name = name;
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}