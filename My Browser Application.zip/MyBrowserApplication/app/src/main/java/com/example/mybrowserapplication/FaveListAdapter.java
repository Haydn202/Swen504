package com.example.mybrowserapplication;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

//I think this one works now
public class FaveListAdapter extends BaseAdapter {

    private List<Favorite> itemList;

    private LayoutInflater inflater;

    FaveListAdapter(Activity context, List<Favorite> itemList) {
        super();
        this.itemList = itemList;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    public Object getItem(int position) {
        return itemList.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public static class ViewHolder {
        TextView txtViewName;
        TextView txtViewURL;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.favoriteitem, null);
            Favorite f = (Favorite) itemList.get(position);
            holder.txtViewName = (TextView) convertView.findViewById(R.id.textViewName);
            holder.txtViewURL = (TextView) convertView.findViewById(R.id.textViewURL);
            holder.txtViewName.setText(f.getName());
            holder.txtViewURL.setText(f.getUrl());
            convertView.setTag(holder);
            //return convertView;
        } else {
            holder = (ViewHolder) convertView.getTag();

            Favorite f = (Favorite) itemList.get(position);
            holder.txtViewName.setText(f.getName());
            holder.txtViewURL.setText(f.getUrl());
            return convertView;
        }

        return convertView;
    }
}

